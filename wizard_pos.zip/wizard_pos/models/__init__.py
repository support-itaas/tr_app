# -*- coding: utf-8 -*-
# Copyright (C) 2019-Today  Technaureus Info Solutions Pvt Ltd.(<http://technaureus.com/>).
from . import pos_config
from . import pos_order
from . import pos_session
from . import project
from . import res_partner
from . import account_bank_statement
